"""Sales analysis logic: load data, detect columns, compute trends + reasons."""
import io
import re
import numpy as np
import pandas as pd

PATTERNS = {
    "stock": r"stock|inventory|on.?hand|available|remaining|balance",
    "cost":  r"cost|purchase|buy|bought|cogs|manufactur|production",
    "date":  r"date|month|day|period",
    "qty":   r"qty|quantity|units|sold|volume",
    "price": r"price|rate|mrp|selling",
    "rev":   r"revenue|sales|amount|total",
    "group": r"product|item|sku|name|category",
}


def load_file(file_storage):
    name = file_storage.filename.lower()
    data = file_storage.read()
    if name.endswith((".xlsx", ".xls")):
        return pd.read_excel(io.BytesIO(data))
    sep = "\t" if name.endswith(".tsv") else None
    return pd.read_csv(io.BytesIO(data), sep=sep, engine="python")


def detect_columns(df):
    found = {}
    for key, pat in PATTERNS.items():
        taken = [v for v in found.values() if v]
        found[key] = next((c for c in df.columns if c not in taken and re.search(pat, str(c), re.I)), None)
    if not found["group"]:
        found["group"] = df.columns[0]
    return found


def _num(s):
    return pd.to_numeric(s.astype(str).str.replace(r"[^0-9.\-]", "", regex=True), errors="coerce")


def prepare(df, m):
    d = pd.DataFrame()
    d["group"] = df[m["group"]].astype(str).str.strip()
    q = _num(df[m["qty"]]) if m.get("qty") else pd.Series(np.nan, index=df.index)
    p = _num(df[m["price"]]) if m.get("price") else pd.Series(np.nan, index=df.index)
    v = _num(df[m["rev"]]) if m.get("rev") else pd.Series(np.nan, index=df.index)
    q = q.fillna(v / p.replace(0, np.nan)).fillna(1)
    v = v.fillna(q * p)
    d["qty"], d["rev"] = q, v
    d["stock"] = _num(df[m["stock"]]) if m.get("stock") else np.nan
    if m.get("cost"):  # unit cost -> total cost (or already a total-cost column)
        c = _num(df[m["cost"]])
        d["cost"] = c if re.search("total", str(m["cost"]), re.I) else c * q
    else:
        d["cost"] = np.nan
    d["date"] = pd.to_datetime(df[m["date"]], errors="coerce") if m.get("date") else pd.NaT
    return d.dropna(subset=["rev"]).query("group != ''")


def analyse(d):
    L = d.groupby("group").agg(units=("qty", "sum"), revenue=("rev", "sum")).reset_index()
    L["avg_price"] = L["revenue"] / L["units"].replace(0, np.nan)
    has_cost = d["cost"].notna().any()
    if has_cost:
        L["total_cost"] = L["group"].map(d.groupby("group")["cost"].sum(min_count=1))
        L["avg_cost"] = L["total_cost"] / L["units"].replace(0, np.nan)
        L["profit"] = L["revenue"] - L["total_cost"]
        L["margin"] = L["profit"] / L["revenue"].replace(0, np.nan) * 100
    has_date = d["date"].notna().sum() > 3
    if has_date:
        cut = d["date"].min() + (d["date"].max() - d["date"].min()) / 2
        a = d[d["date"] <= cut].groupby("group")[["qty", "rev"]].sum()
        b = d[d["date"] > cut].groupby("group")[["qty", "rev"]].sum()
    mu, mp = L["units"].median(), L["avg_price"].median()

    trends, changes, reasons = [], [], []
    for _, r in L.iterrows():
        R, tr, ch = [], "N/A", None
        if has_date:
            qa = a["qty"].get(r.group, 0); qb = b["qty"].get(r.group, 0)
            if qa > 0 and qb > 0:
                ch = (qb - qa) / qa * 100
                pa, pb = a["rev"][r.group] / qa, b["rev"][r.group] / qb
                pc = (pb - pa) / pa * 100 if pa else 0
                tr = "Growing" if ch > 10 else "Declining" if ch < -10 else "Stable"
                if tr == "Declining":
                    R.append(f"Price rose {pc:.0f}% and units fell {abs(ch):.0f}%" if pc > 5 else
                             f"Units fell {abs(ch):.0f}% even after a price cut - weak demand" if pc < -5 else
                             f"Units fell {abs(ch):.0f}% at a steady price - check competition/seasonality")
                elif tr == "Growing":
                    R.append(f"Price cut of {abs(pc):.0f}% lifted sales {ch:.0f}%" if pc < -5 else
                             f"Sales up {ch:.0f}% despite a price rise - strong demand" if pc > 5 else
                             f"Steady demand growth (+{ch:.0f}%)")
                else:
                    R.append("Demand steady between periods")
            else:
                R.append("No sales in recent period - stopped selling" if qa > 0
                         else "New product / no earlier sales to compare")
        else:
            R.append("No date column - trend not available")
        if r.units > 1.5 * mu: R.append("Best seller (high volume)")
        elif r.units < 0.5 * mu:
            R.append("High price and low units sold" if r.avg_price > 1.3 * mp else "Low units sold")
        elif r.avg_price > 1.3 * mp and r.units < mu: R.append("High price limiting sales")
        if r.avg_price < 0.75 * mp and r.units > mu: R.append("Low price driving volume")
        if has_cost and pd.notna(r.margin):
            if r.profit < 0: R.append(f"Selling below cost - losing {abs(r.margin):.0f}% on every sale; raise the price or cut the cost")
            elif r.margin < 15: R.append(f"Low margin ({r.margin:.0f}%) - price is too close to cost")
            elif r.margin > 50: R.append(f"High-margin item ({r.margin:.0f}%)")
        trends.append(tr); changes.append(None if ch is None else round(ch, 1)); reasons.append(". ".join(R))
    L["unit_change_pct"], L["trend"], L["reason"] = changes, trends, reasons
    if d["stock"].notna().any():
        st = d.sort_values("date", na_position="first").dropna(subset=["stock"]).groupby("group")["stock"].last()
        L["stock"] = L["group"].map(st)
        span = max((d["date"].max() - d["date"].min()).days, 1) if has_date else None
        L["days_left"] = (L["stock"] / (L["units"] / span)).replace([np.inf, -np.inf], np.nan) if span else np.nan
        stat, extra = [], []
        for _, r in L.iterrows():
            if pd.isna(r.stock): stat.append("Unknown"); extra.append(""); continue
            cover = r.days_left if span else (r.stock / r.units * 365 if r.units else np.nan)
            if r.stock <= 0: s_, t = "Out of stock", "Out of stock - sales are being lost, reorder now"
            elif pd.notna(cover) and cover < 15: s_, t = "Low stock", f"Only ~{cover:.0f} days of stock left - reorder soon"
            elif pd.isna(cover) or cover > 120: s_, t = "Overstock", "Overstocked (very slow-moving) - consider a discount or promotion" if pd.notna(cover) else "Stock but no recent sales - check demand"
            else: s_, t = "Healthy", ""
            if s_ == "Overstock" and pd.notna(cover): t = f"Overstocked (~{cover:.0f} days of stock) - consider a discount or promotion"
            stat.append(s_); extra.append(t)
        L["stock_status"] = stat
        if has_cost: L["stock_value"] = (L["stock"] * L["avg_cost"]).round(2)
        L["sell_through"] = (L["units"] / (L["units"] + L["stock"]).replace(0, np.nan) * 100).round(1)
        if span: L["reorder_qty"] = [max(0, round(u / span * 30 - k)) if t in ("Low stock", "Out of stock") else None for u, k, t in zip(L["units"], L["stock"], stat)]
        L["reason"] = [(a + ". " + b) if b else a for a, b in zip(L["reason"], extra)]
    L = L.sort_values("revenue", ascending=False).reset_index(drop=True)
    prev = L["revenue"].cumsum() - L["revenue"]
    L["abc"] = np.where(prev < 0.8 * L["revenue"].sum(), "A", np.where(prev < 0.95 * L["revenue"].sum(), "B", "C"))
    return L


def clean(df):
    return df.astype(object).where(df.notna(), None).to_dict("records")


def filter_options(df, m):
    used = [v for v in m.values() if v]
    cats = {str(c): sorted(df[c].dropna().astype(str).unique().tolist()) for c in df.columns
            if c not in used and pd.api.types.is_string_dtype(df[c]) and 1 < df[c].nunique() <= 30}
    dr = pd.to_datetime(df[m["date"]], errors="coerce").dropna() if m.get("date") else pd.Series(dtype="datetime64[ns]")
    return {"cats": cats, "min": str(dr.min().date()) if len(dr) else None, "max": str(dr.max().date()) if len(dr) else None}


def run(df, m=None, start=None, end=None, cat=None, val=None):
    m = m or detect_columns(df)
    if cat and val and cat in df.columns:
        df = df[df[cat].astype(str) == val]
    if m.get("date") and (start or end):
        dd = pd.to_datetime(df[m["date"]], errors="coerce")
        if start: keep = dd >= pd.to_datetime(start); df, dd = df[keep], dd[keep]
        if end: df = df[dd <= pd.to_datetime(end)]
    df = df.reset_index(drop=True)
    if df.empty:
        raise ValueError("No rows match the selected filters.")
    d = prepare(df, m)
    if d.empty:
        raise ValueError("No usable rows. Need a revenue column, or price + quantity columns.")
    L = analyse(d)
    has_stock = "stock" in L
    monthly = {}
    if d["date"].notna().any():
        s = d.dropna(subset=["date"]).groupby(d["date"].dt.to_period("M"))["rev"].sum()
        monthly = {str(k): round(float(v), 2) for k, v in s.items()}
    tot, units = float(d["rev"].sum()), float(d["qty"].sum())
    kpis = {"Total revenue": round(tot, 2), "Units sold": round(units, 2),
            "Avg unit price": round(tot / max(units, 1), 2), "Top performer": str(L.iloc[0]["group"]),
            "Items analysed": len(L)}
    if has_stock:
        kpis["Units in stock"] = round(float(L["stock"].sum()), 0)
        kpis["Need reorder"] = int(L["stock_status"].isin(["Low stock", "Out of stock"]).sum())
        kpis["Overstocked"] = int((L["stock_status"] == "Overstock").sum())
    has_cost = "profit" in L
    if has_cost:
        tc, tp = float(L["total_cost"].sum()), float(L["profit"].sum())
        kpis["Total cost"], kpis["Total profit"], kpis["Profit margin"] = round(tc, 2), round(tp, 2), f"{tp / tot * 100:.1f}%"
        if has_stock: kpis["Stock value (at cost)"] = round(float(L["stock_value"].sum()), 0)
    used = set(v for v in m.values() if v)
    breakdowns = []
    for c in df.columns:
        if c not in used and pd.api.types.is_string_dtype(df[c]) and 1 < df[c].nunique() <= 15:
            g = d.groupby(df.loc[d.index, c].astype(str))[["qty", "rev", "cost"]].sum().sort_values("rev", ascending=False)
            breakdowns.append({"by": str(c), "rows": [{"name": k, "units": round(float(r.qty), 2),
                "revenue": round(float(r.rev), 2), "profit": round(float(r.rev - r.cost), 2) if has_cost else None, "share": round(float(r.rev) / tot * 100, 1)} for k, r in g.iterrows()]})
    stats = df.select_dtypes("number").describe().T[["count", "mean", "min", "max"]].round(2).reset_index()
    stats.columns = ["column", "count", "mean", "min", "max"]
    miss = pd.DataFrame({"column": df.columns.astype(str), "missing": df.isna().sum().values})
    miss["percent"] = (miss["missing"] / len(df) * 100).round(1)
    ins = [("info", f"Top 3 items ({', '.join(L['group'].head(3))}) generate {L['revenue'].head(3).sum() / tot * 100:.0f}% of total revenue.")]
    dated = d.dropna(subset=["date"])
    if len(dated) > 3:
        cut = dated["date"].min() + (dated["date"].max() - dated["date"].min()) / 2
        ra, rb = dated[dated["date"] <= cut]["rev"].sum(), dated[dated["date"] > cut]["rev"].sum()
        if ra:
            g = (rb - ra) / ra * 100; kpis["Revenue trend"] = f"{g:+.1f}%"
            ins.append(("good" if g >= 0 else "bad", f"Revenue in the second half of the period is {abs(g):.1f}% {'higher' if g >= 0 else 'lower'} than the first half."))
    gr = L.dropna(subset=["unit_change_pct"])
    if len(gr):
        b, w = gr.loc[gr["unit_change_pct"].idxmax()], gr.loc[gr["unit_change_pct"].idxmin()]
        ins.append(("good", f"Fastest growing: {b.group} ({b.unit_change_pct:+.0f}% units)."))
        if w.unit_change_pct < 0: ins.append(("bad", f"Biggest decline: {w.group} ({w.unit_change_pct:+.0f}% units) - {w.reason.split('. ')[0]}."))
    if has_stock:
        for st, ty, msg in [("Out of stock", "bad", "Out of stock: {}"), ("Low stock", "bad", "Running low, reorder soon: {}"), ("Overstock", "info", "Overstocked (cash tied up): {}")]:
            n = L[L["stock_status"] == st]["group"].tolist()
            if n: ins.append((ty, msg.format(", ".join(n))))
    ins.append(("info", f"{int((L['abc'] == 'C').sum())} of {len(L)} items are class C (bottom 5% of revenue)."))
    if has_cost:
        ins.append(("good" if tp >= 0 else "bad", f"Total profit is {tp:,.0f} ({tp / tot * 100:.1f}% margin) on revenue of {tot:,.0f}."))
        pm = L.dropna(subset=["profit"]); bp = pm.loc[pm["profit"].idxmax()]
        ins.append(("good", f"Most profitable: {bp.group} ({bp.profit:,.0f} profit, {bp.margin:.0f}% margin)."))
        loss = pm[pm["profit"] < 0]["group"].tolist()
        if loss: ins.append(("bad", f"Selling below cost (losing money): {', '.join(loss)}"))
        lowm = pm[(pm["margin"] >= 0) & (pm["margin"] < 15)]["group"].tolist()
        if lowm: ins.append(("bad", f"Thin margins under 15%: {', '.join(lowm)}"))
        if has_stock: ins.append(("info", f"Stock on hand holds {L['stock_value'].sum():,.0f} of cash at cost."))
    fc = None
    if len(monthly) >= 3:
        y = np.array(list(monthly.values())); k, b0 = np.polyfit(np.arange(len(y)), y, 1)
        fc = {"label": str(pd.Period(list(monthly)[-1]) + 1), "value": round(float(max(k * len(y) + b0, 0)), 2)}
    span = max((d["date"].max() - d["date"].min()).days, 1) if d["date"].notna().sum() > 1 else None
    ok = lambda x: x is not None and not pd.isna(x)
    acts, restock, tied = [], 0.0, 0.0
    def A(p, item, do, why, imp=None, lab=None):
        acts.append({"priority": p, "item": item, "action": do, "why": why, "impact": None if imp is None else round(float(imp), 2), "label": lab})
    for r in L.to_dict("records"):
        g, st, mg, pf, ac = r["group"], r.get("stock_status"), r.get("margin"), r.get("profit"), r.get("avg_cost")
        if st in ("Out of stock", "Low stock"):
            q = r.get("reorder_qty"); cost = q * ac if ok(q) and ok(ac) else 0; restock += cost
            A("Urgent", g, f"Reorder {q:,.0f} units (enough for 30 days)" if ok(q) else "Reorder now",
              "Out of stock - you are losing sales" if st == "Out of stock" else f"Only ~{r['days_left']:.0f} days of stock left", cost or None, "needed to restock")
        if ok(pf) and pf < 0:
            A("Urgent", g, f"Raise price to at least {ac / 0.8:,.0f} (20% margin) or cut your cost", f"Selling below cost - losing {abs(mg):.0f}% on every sale", abs(pf), "lost so far")
        elif ok(mg) and mg < 15:
            A("Important", g, f"Raise price towards {ac / 0.8:,.0f} or find a cheaper supplier", f"Margin is only {mg:.0f}%")
        if st == "Overstock":
            sv = r.get("stock_value"); tied += sv if ok(sv) else 0
            A("Important", g, "Stop reordering; run a discount or bundle offer", "Far more stock than you can sell soon", sv if ok(sv) else None, "of cash tied up")
        if r["trend"] == "Declining" and "Price rose" in r["reason"]:
            A("Important", g, "Test rolling back the recent price increase", f"Units fell {abs(r['unit_change_pct']):.0f}% after the price went up")
        elif r["trend"] == "Declining" and r["abc"] == "A":
            A("Urgent", g, "Find out why this top earner is falling (price, competitor, quality?)", f"Units down {abs(r['unit_change_pct']):.0f}% on a class A item")
        if r["trend"] == "Growing" and st in ("Low stock", "Healthy", None):
            A("Opportunity", g, "Stock up and promote - demand is rising", f"Units up {r['unit_change_pct']:.0f}%")
        if r["trend"] == "N/A" and "stopped" in r["reason"]:
            A("Important", g, "Clear leftover stock or remove from your catalogue", "No sales in the recent period")
        if ok(mg) and mg > 50 and r["abc"] != "A":
            A("Opportunity", g, "Promote this high-margin item more", f"{mg:.0f}% margin but not a top seller")
    acts.sort(key=lambda a: {"Urgent": 0, "Important": 1, "Opportunity": 2}[a["priority"]])
    if has_stock and span: kpis["Cash needed to restock"] = round(restock, 0)
    if has_stock and has_cost: kpis["Cash tied in overstock"] = round(tied, 0)
    top = L.head(10)
    dr = d["date"].dropna()
    return {
        "columns": {k: v for k, v in m.items() if v}, "kpis": kpis, "has_stock": has_stock,
        "rows": len(df), "ncols": df.shape[1],
        "date_range": f"{dr.min():%d %b %Y} - {dr.max():%d %b %Y}" if len(dr) else "No date column",
        "top": {"labels": top["group"].tolist(), "values": top["revenue"].round(2).tolist()},
        "units": {"labels": L["group"].tolist(), "values": L["units"].round(2).tolist(),
                  "stock": L["stock"].round(2).tolist() if has_stock else [],
                  "cost": L["total_cost"].round(2).tolist() if has_cost else [], "profit": L["profit"].round(2).tolist() if has_cost else [], "revenue": L["revenue"].round(2).tolist()},
        "has_cost": has_cost,
        "monthly": monthly, "trend_counts": L["trend"].value_counts().to_dict(),
        "stock_counts": L["stock_status"].value_counts().to_dict() if has_stock else {},
        "table": clean(L.round(2)), "breakdowns": breakdowns,
        "preview": clean(df.head(10).astype(str)), "preview_cols": [str(c) for c in df.columns],
        "stats": clean(stats), "missing": clean(miss),
        "insights": [{"type": t, "text": x} for t, x in ins], "forecast": fc, "actions": acts,
    }
