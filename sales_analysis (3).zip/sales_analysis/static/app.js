const $=id=>document.getElementById(id),PAGE=document.body.dataset.page;
const fmt=n=>n==null?'-':Number(n).toLocaleString(undefined,{maximumFractionDigits:2});
const cls=s=>({'Out of stock':'Out','Low stock':'Low','Overstock':'Over','N/A':'NA'}[s]||s);
const COL={Growing:'#16a34a',Declining:'#dc2626',Stable:'#f59e0b',Healthy:'#16a34a','Low stock':'#f59e0b','Out of stock':'#dc2626',Overstock:'#7c3aed',Unknown:'#94a3b8','N/A':'#94a3b8'};
const chart=(id,cfg)=>new Chart($(id),cfg),base={maintainAspectRatio:false,plugins:{legend:{display:false}}};
const tag=s=>`<span class="tag ${cls(s)}">${s??'-'}</span>`;
function tbl(id,cols,rows){$(id).innerHTML='<thead><tr>'+cols.map(c=>`<th class="${c[2]?'n':''}">${c[1]}</th>`).join('')+'</tr></thead><tbody>'+
  (rows.map(r=>'<tr>'+cols.map(c=>{let v=r[c[0]];v=c[3]?c[3](v,r):(c[2]?(MK.has(c[0])?M(v):fmt(v)):(v??''));return`<td class="${c[2]?'n':''}">${v}</td>`}).join('')+'</tr>').join('')||`<tr><td colspan="${cols.length}">Nothing to show</td></tr>`)+'</tbody>'}
const CUR=localStorage.getItem('cur')||'₹';
const cmp=n=>{const a=Math.abs(n);return CUR==='₹'?(a>=1e7?(n/1e7).toFixed(2)+' Cr':a>=1e5?(n/1e5).toFixed(2)+' L':fmt(n)):(a>=1e6?(n/1e6).toFixed(2)+'M':a>=1e4?(n/1e3).toFixed(1)+'K':fmt(n))};
const M=(n,c)=>n==null?'-':(n<0?'-':'')+CUR+(c?cmp(Math.abs(n)):fmt(Math.abs(n)));
const MK=new Set(['revenue','avg_price','avg_cost','profit','stock_value','total_cost']);
const MKP=new Set(['Total revenue','Avg unit price','Total cost','Total profit','Stock value (at cost)','Cash needed to restock','Cash tied in overstock']);
const kpi=(k,v)=>`<div class="kpi"><b>${typeof v==='number'?(MKP.has(k)?M(v,1):fmt(v)):v}</b><span>${k}</span></div>`;
const kpis=o=>Object.entries(o).map(([k,v])=>kpi(k,v)).join('');
const PCOL={Urgent:'Out',Important:'Low',Opportunity:'Healthy'};
const actionCard=a=>`<div class="act ${a.priority}"><div><span class="tag ${PCOL[a.priority]}">${a.priority}</span> <b>${a.item}</b></div><div>${a.action}</div><div class="mut">${a.why}${a.impact!=null?` · <b>${M(a.impact,1)}</b> ${a.label||''}`:''}</div></div>`;
const cs=$('cur');if(cs){cs.value=CUR;cs.onchange=()=>{localStorage.setItem('cur',cs.value);location.reload()}}
let D=null;

/* ---------- upload page ---------- */
if(PAGE==='upload'){
  const fi=$('file'),dz=$('drop');
  const picked=()=>{const f=fi.files[0];$('go').disabled=!f;$('chosen').classList.toggle('hide',!f);dz.classList.toggle('done',!!f);
    if(f){$('fname').textContent='📄 '+f.name;$('fsize').textContent=(f.size/1024).toFixed(1)+' KB';$('dtitle').textContent='File ready - click Analyse'}else $('dtitle').textContent='Drag & drop your sales file here'};
  fi.onchange=picked;$('clr').onclick=()=>{fi.value='';picked()};
  ['dragenter','dragover'].forEach(t=>dz.addEventListener(t,e=>{e.preventDefault();dz.classList.add('on')}));
  ['dragleave','drop'].forEach(t=>dz.addEventListener(t,e=>{e.preventDefault();dz.classList.remove('on')}));
  dz.addEventListener('drop',e=>{if(e.dataTransfer.files.length){fi.files=e.dataTransfer.files;picked()}});
  const busy=b=>{$('go').disabled=b;$('spin').classList.toggle('hide',!b);$('gotxt').textContent=b?'Analysing...':'Analyse data'};
  $('f').onsubmit=async e=>{e.preventDefault();$('err').textContent='';busy(true);
    try{const r=await fetch('/analyse',{method:'POST',body:new FormData($('f'))});const j=await r.json();
      if(!r.ok){$('err').textContent=j.error;busy(false);picked();return}location='/summary'}
    catch(x){$('err').textContent='Could not reach the server. Is python app.py running?';busy(false);picked()}};
}else boot();

async function boot(){
  document.querySelectorAll('#nav a[data-p]').forEach(a=>a.href='/'+a.dataset.p+location.search);
  const r=await fetch('/api/data'+location.search);
  if(r.status===404){location='/';return}
  const j=await r.json();$('loading').classList.add('hide');
  if(!r.ok){$('err').textContent=j.error+' - try Reset in the filter bar.';filterBar(null);return}
  D=j;filterBar(j);$('content').classList.remove('hide');R[PAGE]();
}
function filterBar(j){
  const q=new URLSearchParams(location.search),o=(j||{}).opts||{cats:{},min:'',max:''};
  const cats=Object.keys(o.cats||{});
  $('filters').innerHTML=`<span class="mut">📁 ${j?j.file:''}</span>`+
   (o.min?`<label>From <input type="date" id="fs" value="${q.get('start')||''}" min="${o.min}" max="${o.max}"></label><label>To <input type="date" id="fe" value="${q.get('end')||''}" min="${o.min}" max="${o.max}"></label>`:'')+
   (cats.length?`<label><select id="fc"><option value="">All categories</option>${cats.map(c=>`<option ${q.get('cat')===c?'selected':''}>${c}</option>`).join('')}</select><select id="fv"></select></label>`:'')+
   `<button class="p" id="ap">Apply</button><button id="rs">Reset</button>`;
  if(cats.length){const fill=()=>{const c=$('fc').value;$('fv').innerHTML=c?(o.cats[c]||[]).map(v=>`<option ${q.get('val')===v?'selected':''}>${v}</option>`).join(''):'<option value="">-</option>';$('fv').disabled=!c};$('fc').onchange=fill;fill()}
  $('ap').onclick=()=>{const p=new URLSearchParams();if($('fs')&&$('fs').value)p.set('start',$('fs').value);if($('fe')&&$('fe').value)p.set('end',$('fe').value);
    if($('fc')&&$('fc').value){p.set('cat',$('fc').value);p.set('val',$('fv').value)}location.search=p.toString()};
  $('rs').onclick=()=>location.search='';
}

/* ---------- pages ---------- */
const R={
summary(){
  $('meta').textContent=`${D.file} · ${D.rows} rows · ${D.date_range} · Top seller: ${D.kpis['Top performer']}`;
  const k=D.kpis,g=(t,keys)=>{const o={};keys.forEach(x=>{if(k[x]!=null)o[x]=k[x]});return Object.keys(o).length?`<h3 class="grp">${t}</h3><div class="kpis">${kpis(o)}</div>`:''};
  $('kpis').innerHTML=g('💰 Sales',['Total revenue','Units sold','Avg unit price','Revenue trend'])+g('📈 Profit',['Total cost','Total profit','Profit margin'])+g('📦 Stock',['Units in stock','Stock value (at cost)','Need reorder','Overstocked','Cash needed to restock','Cash tied in overstock']);
  const rt=parseFloat(k['Revenue trend']),pm=parseFloat(k['Profit margin']),H=[];
  H.push(isNaN(rt)?['grey','Sales','Add a Date column to see the sales trend']:[rt>=0?'green':'red','Sales',`Sales ${rt>=0?'up':'down'} ${Math.abs(rt)}% vs the earlier half of the period`]);
  H.push(isNaN(pm)?['grey','Profit','Add a Cost Price column to see profit']:[pm>=20?'green':pm>=10?'amber':'red','Profit',`Margin ${pm}% - ${pm>=20?'healthy':pm>=10?'thin':'dangerously thin'}`]);
  H.push(!D.has_stock?['grey','Stock','Add a Stock column to see inventory health']:[k['Need reorder']>0?'red':k['Overstocked']>0?'amber':'green','Stock',`${k['Need reorder']} need reordering, ${k['Overstocked']} overstocked`]);
  $('health').innerHTML=H.map(h=>`<div class="hl ${h[0]}"><span class="dot"></span><div><b>${h[1]}</b><br><span>${h[2]}</span></div></div>`).join('');
  $('top3').innerHTML=D.actions.slice(0,3).map(actionCard).join('')||'<p class="mut">Nothing urgent 🎉</p>';
  $('ins').innerHTML=D.insights.map(i=>`<li class="${i.type}">${i.text}</li>`).join('');
  const ab=['A','B','C'].map(k=>{const r=D.table.filter(o=>o.abc===k);return{abc:k,items:r.length,revenue:r.reduce((s,o)=>s+o.revenue,0)}});const t=ab.reduce((s,o)=>s+o.revenue,0);ab.forEach(o=>o.share=t?o.revenue/t*100:0);
  tbl('t_abc',[['abc','Class',0,tag],['items','Items',1],['revenue','Revenue',1],['share','Share %',1]],ab);
  const c=[['group','Item'],['revenue','Revenue',1],['units','Units',1],['trend','Trend',0,tag]];if(D.has_cost)c.splice(2,0,['profit','Profit',1],['margin','Margin %',1]);
  tbl('t_top',c,D.table.slice(0,5));tbl('t_bot',c,D.table.slice(-5).reverse());
},
actions(){const A=D.actions,c=p=>A.filter(a=>a.priority===p),k=D.kpis;
  $('akpi').innerHTML=kpis({Urgent:c('Urgent').length,Important:c('Important').length,Opportunities:c('Opportunity').length,...(k['Cash needed to restock']!=null?{'Cash needed to restock':k['Cash needed to restock']}:{}),...(k['Cash tied in overstock']!=null?{'Cash tied in overstock':k['Cash tied in overstock']}:{})});
  ['Urgent','Important','Opportunity'].forEach(p=>$('a_'+p).innerHTML=c(p).map(actionCard).join('')||'<p class="mut">Nothing here.</p>');
},
stock(){
  if(!D.has_stock){$('nostock').classList.remove('hide');$('stockwrap').classList.add('hide');return}
  const k=D.kpis;$('kpis').innerHTML=kpis({'Units in stock':k['Units in stock'],'Need reorder':k['Need reorder'],'Overstocked':k['Overstocked'],'Items':k['Items analysed'],...(D.has_cost?{'Stock value (at cost)':k['Stock value (at cost)']}:{})});
  const sk=Object.keys(D.stock_counts);chart('c1',{type:'doughnut',data:{labels:sk,datasets:[{data:Object.values(D.stock_counts),backgroundColor:sk.map(x=>COL[x])}]},options:{maintainAspectRatio:false}});
  const al=D.table.filter(o=>o.stock_status!=='Healthy').sort((a,b)=>(a.days_left??-1)-(b.days_left??-1));
  tbl('t_alert',[['group','Item'],['stock','In stock',1],['stock_status','Status',0,tag],['reorder_qty','Order qty',1,v=>v==null?'-':'<b>'+fmt(v)+'</b>']],al);
  tbl('t_stock',[['group','Item'],['stock','In stock',1],['units','Units sold',1],['days_left','Days left',1],['sell_through','Sell-through %',1],['stock_status','Status',0,tag],['reorder_qty','Order qty (30-day cover)',1],...(D.has_cost?[['stock_value','Stock value (cost)',1]]:[])],[...D.table].sort((a,b)=>(a.days_left??-1)-(b.days_left??-1)));
},
charts(){
  const T=D.table,tot=T.reduce((s,o)=>s+o.revenue,0);let c=0;const cum=T.map(o=>(c+=o.revenue)/tot*100);
  chart('c1',{data:{labels:T.map(o=>o.group),datasets:[{type:'bar',label:'Revenue',data:T.map(o=>o.revenue),backgroundColor:'#2563eb',yAxisID:'y'},{type:'line',label:'Cumulative %',data:cum,borderColor:'#f59e0b',yAxisID:'y1'}]},options:{maintainAspectRatio:false,scales:{y1:{position:'right',max:100,grid:{drawOnChartArea:false}}}}});
  const mk=Object.keys(D.monthly),mv=Object.values(D.monthly),f=D.forecast;
  const ds=[{label:'Revenue',data:[...mv,...(f?[null]:[])],borderColor:'#2563eb',backgroundColor:'#2563eb33',fill:true,tension:.3}];
  if(f)ds.push({label:'Forecast',data:[...mv.map((_,i)=>i===mv.length-1?mv[i]:null),f.value],borderColor:'#f59e0b',borderDash:[6,4],pointStyle:'triangle',pointRadius:6});
  chart('c2',{type:'line',data:{labels:mk.length?[...mk,...(f?[f.label]:[])]:['No date column'],datasets:mk.length?ds:[{data:[0]}]},options:{maintainAspectRatio:false}});
  if(D.has_stock){$('c3t').textContent='Units sold vs units in stock';chart('c3',{type:'bar',data:{labels:D.units.labels,datasets:[{label:'Units sold',data:D.units.values,backgroundColor:'#2563eb'},{label:'In stock',data:D.units.stock,backgroundColor:'#f59e0b'}]},options:{maintainAspectRatio:false}})}
  else chart('c3',{type:'bar',data:{labels:D.units.labels,datasets:[{data:D.units.values,backgroundColor:'#16a34a'}]},options:base});
  const tk=Object.keys(D.trend_counts);chart('c4',{type:'doughnut',data:{labels:tk,datasets:[{data:Object.values(D.trend_counts),backgroundColor:tk.map(x=>COL[x])}]},options:{maintainAspectRatio:false}});
  const HT=['Few items earn most of your money. Items before the 80% mark on the line are your stars.','The dotted line is a rough guess for next month, based on the recent trend.','If the stock bar is much taller than units sold, you are overstocked.','Green (profit) should sit well above zero. No green bar means you lose money on that item.','How many items are growing, flat or falling.'];
  document.querySelectorAll('.charts .card h2').forEach((h,i)=>h.insertAdjacentHTML('afterend',`<p class="hint">${HT[i]||''}</p>`));
  if(D.has_cost){$('costcard').classList.remove('hide');chart('c5',{type:'bar',data:{labels:D.units.labels,datasets:[{label:'Revenue',data:D.units.revenue,backgroundColor:'#2563eb'},{label:'Cost',data:D.units.cost,backgroundColor:'#94a3b8'},{label:'Profit',data:D.units.profit,backgroundColor:'#16a34a'}]},options:{maintainAspectRatio:false}})}
},
trends(){
  let sk='revenue',sd=-1;
  const H=()=>{const h=[['group','Item'],['abc','ABC'],['units','Units sold','n'],['avg_price','Avg price','n'],['revenue','Revenue','n'],['unit_change_pct','Change %','n'],['trend','Trend']];
    if(D.has_cost)h.push(['avg_cost','Avg cost','n'],['profit','Profit','n'],['margin','Margin %','n']);if(D.has_stock)h.push(['stock','In stock','n'],['days_left','Days left','n'],['stock_status','Stock status']);h.push(['reason','Reason']);return h};
  const head=()=>{$('th').innerHTML='<tr>'+H().map(([k,l,c])=>`<th class="s ${c?'n':''}" data-k="${k}">${l}${sk===k?(sd>0?' ▲':' ▼'):''}</th>`).join('')+'</tr>';
    document.querySelectorAll('#th th').forEach(t=>t.onclick=()=>{const k=t.dataset.k;sd=sk===k?-sd:-1;sk=k;head();draw()})};
  const draw=()=>{const q=$('q').value.toLowerCase(),f=$('tf').value;
    const L=D.table.filter(o=>(!f||o.trend===f)&&(!q||(o.group+o.reason).toLowerCase().includes(q)));
    L.sort((a,b)=>{const x=a[sk]??-Infinity,y=b[sk]??-Infinity;return(typeof x==='string'?x.localeCompare(y):x-y)*sd});
    $('tb').innerHTML=L.map(o=>'<tr>'+H().map(([k,,n])=>{let v=o[k];
      if(k==='trend'||k==='stock_status'||k==='abc')v=tag(v);else if(k==='unit_change_pct')v=v==null?'-':(v>0?'+':'')+v+'%';else if(k==='reason')return`<td class="w">${v}</td>`;else if(k==='group')v='<b>'+v+'</b>';else if(k==='profit'||k==='margin')v=`<span style="color:${o.profit<0?'var(--dn)':'var(--up)'}">${k==='profit'?M(v):fmt(v)}</span>`;else if(n)v=MK.has(k)?M(v):fmt(v);
      return`<td class="${n?'n':''}">${v}</td>`}).join('')+'</tr>').join('')||'<tr><td colspan="11">No matches</td></tr>'};
  $('q').oninput=draw;$('tf').onchange=draw;head();draw();
  $('dl').onclick=()=>{const h=H();const csv=[h.map(x=>x[1]).join(',')].concat(D.table.map(o=>h.map(([k])=>'"'+String(o[k]??'').replace(/"/g,'""')+'"').join(','))).join('\n');
    const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download='sales_analysis_results.csv';a.click()};
},
breakdown(){
  if(!D.breakdowns.length){$('nobd').classList.remove('hide');return}
  $('bd').innerHTML=D.breakdowns.map((b,i)=>`<div class="card"><h2>Revenue by ${b.by}</h2><div class="cv" style="height:220px"><canvas id="bc${i}"></canvas></div><div class="scroll" style="margin-top:10px"><table id="b${i}"></table></div></div>`).join('');
  D.breakdowns.forEach((b,i)=>{tbl('b'+i,[['name',b.by],['units','Units',1],['revenue','Revenue',1],...(D.has_cost?[['profit','Profit',1]]:[]),['share','Share %',1]],b.rows);
    chart('bc'+i,{type:'bar',data:{labels:b.rows.map(r=>r.name),datasets:[{data:b.rows.map(r=>r.revenue),backgroundColor:'#2563eb'}]},options:base})});
},
data(){
  const nm={group:'Item',date:'Date',qty:'Quantity',price:'Unit price',rev:'Revenue',stock:'Stock',cost:'Cost price'};
  tbl('t_cols',[['role','Meaning'],['col','Column in your file']],Object.entries(D.columns).map(([r,c])=>({role:nm[r],col:c})));
  tbl('t_miss',[['column','Column'],['missing','Missing',1],['percent','%',1]],D.missing);
  tbl('t_stats',[['column','Column'],['count','Count',1],['mean','Mean',1],['min','Min',1],['max','Max',1]],D.stats);
  tbl('t_prev',D.preview_cols.map(c=>[c,c]),D.preview);
}};
