# Sales Data Analysis (Flask)

Upload a CSV/Excel sales file in the browser and get KPIs, graphs, the
terminal-style text report, and a table with a **Reason** column for each trend.
The same report is also printed in the terminal where the server runs.

## Run
```
python -m venv venv
venv\Scripts\activate        # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
python app.py
```


## Expected columns (names are auto-detected)
Item/Product, Date, Quantity, Unit Price and/or Revenue.
Date is optional, but without it trends can't be calculated.

Charts use Chart.js from a CDN, so the browser needs internet access.
