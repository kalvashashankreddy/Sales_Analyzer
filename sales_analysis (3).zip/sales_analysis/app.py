from flask import Flask, render_template, request, jsonify, abort
import analysis

app = Flask(__name__)
app.json.sort_keys = False
PAGES = ["summary", "actions", "stock", "charts", "trends", "breakdown", "data"]
STORE = {}  # holds the uploaded dataset (single local user)


@app.get("/")
def upload():
    return render_template("upload.html", page="upload")


@app.post("/analyse")
def analyse():
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify(error="Please choose a file."), 400
    try:
        df = analysis.load_file(f)
        m = analysis.detect_columns(df)
        analysis.run(df, m)  # validate
        STORE.update(df=df, m=m, opts=analysis.filter_options(df, m), name=f.filename)
    except Exception as e:
        print("ERROR:", e)
        return jsonify(error=str(e)), 400
    print("Loaded", f.filename, df.shape)
    return jsonify(ok=True)


@app.get("/api/data")
def data():
    if not STORE:
        return jsonify(error="No data uploaded"), 404
    a = request.args
    try:
        r = analysis.run(STORE["df"], STORE["m"], a.get("start") or None, a.get("end") or None, a.get("cat") or None, a.get("val") or None)
    except Exception as e:
        return jsonify(error=str(e)), 400
    r["opts"], r["file"] = STORE["opts"], STORE["name"]
    return jsonify(r)


@app.get("/<page>")
def page(page):
    if page not in PAGES:
        abort(404)
    return render_template("page.html", page=page)


if __name__ == "__main__":
    print("Open http://127.0.0.1:5000 in your browser")
    app.run(debug=True)
